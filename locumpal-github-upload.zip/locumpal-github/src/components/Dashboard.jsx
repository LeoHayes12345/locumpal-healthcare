import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import api from '../lib/axios';
import ComplianceManager from './ComplianceManagerIntegrated';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeView, setActiveView] = useState('dashboard');

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const response = await api.get('/api/sessions');
      setSessions(response.data.sessions || []);
    } catch (err) {
      setError('Failed to load sessions');
      console.error('Error fetching sessions:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">
                <span className="text-blue-600">Locum</span>
                <span className="text-cyan-600">Pal</span>
              </h1>
              <span className="ml-4 px-3 py-1 bg-indigo-100 text-indigo-800 text-sm font-medium rounded-full">
                {user?.lp_id}
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-700">
                Welcome, {user?.first_name || user?.email}
              </span>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="text-gray-600 hover:text-gray-900"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveView('dashboard')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeView === 'dashboard'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Dashboard
            </button>
            {user?.role === 'locum' && (
              <button
                onClick={() => setActiveView('compliance')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeView === 'compliance'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Information Control Center
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'dashboard' && (
          <>
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900">
                {user?.role === 'locum' ? 'Locum Dashboard' : 'Provider Dashboard'}
              </h2>
              <p className="mt-2 text-gray-600">
                {user?.role === 'locum' 
                  ? 'Browse and book available shifts from approved providers'
                  : 'Manage your clinic sessions and approved clinicians'
                }
              </p>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            {/* Quick Actions for Locums */}
            {user?.role === 'locum' && (
              <div className="mb-8">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium text-blue-900">Complete Your Professional Profile</h3>
                      <p className="text-blue-700 mt-1">
                        Upload your compliance documents and complete your professional information to start booking shifts.
                      </p>
                      <div className="mt-2 flex items-center space-x-4 text-sm text-blue-600">
                        <span>• Professional Insurance</span>
                        <span>• DBS Certificate</span>
                        <span>• CQC Registration</span>
                        <span>• ICO Registration</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => setActiveView('compliance')}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Manage Information
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {user?.role === 'locum' ? 'Available Shifts' : 'Open Sessions'}
                </h3>
                <p className="text-3xl font-bold text-indigo-600">
                  {sessions.filter(s => s.state === 'open').length}
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {user?.role === 'locum' ? 'My Bookings' : 'Filled Sessions'}
                </h3>
                <p className="text-3xl font-bold text-green-600">
                  {sessions.filter(s => s.state === 'filled').length}
                </p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Completed
                </h3>
                <p className="text-3xl font-bold text-blue-600">
                  {sessions.filter(s => s.state === 'completed').length}
                </p>
              </div>
            </div>

            {/* Sessions List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">
                  {user?.role === 'locum' ? 'Available Shifts' : 'Your Sessions'}
                </h3>
              </div>
              
              <div className="p-6">
                {sessions.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">
                      {user?.role === 'locum' 
                        ? 'No available shifts at the moment. Check back later!'
                        : 'No sessions created yet. Create your first session to get started.'
                      }
                    </p>
                    {user?.role === 'provider' && (
                      <Button className="mt-4 bg-indigo-600 hover:bg-indigo-700">
                        Create Session
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {sessions.map((session) => (
                      <div key={session.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold text-gray-900">
                              {session.clinic_type || 'General Session'}
                            </h4>
                            <p className="text-sm text-gray-600 mt-1">
                              {session.date} • {session.start_time} - {session.end_time}
                            </p>
                            {session.est_patients && (
                              <p className="text-sm text-gray-600">
                                Estimated patients: {session.est_patients}
                              </p>
                            )}
                            {user?.role === 'locum' && session.provider && (
                              <p className="text-sm text-gray-600">
                                Provider: {session.provider.legal_name} ({session.provider.lp_id})
                              </p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              session.state === 'open' ? 'bg-green-100 text-green-800' :
                              session.state === 'filled' ? 'bg-blue-100 text-blue-800' :
                              session.state === 'completed' ? 'bg-gray-100 text-gray-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {session.state}
                            </span>
                            {session.urgency && (
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                session.urgency === 'red' ? 'bg-red-100 text-red-800' :
                                'bg-amber-100 text-amber-800'
                              }`}>
                                {session.urgency === 'red' ? 'Urgent' : 'Soon'}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {activeView === 'compliance' && user?.role === 'locum' && (
          <ComplianceManager />
        )}
      </main>
    </div>
  );
}

