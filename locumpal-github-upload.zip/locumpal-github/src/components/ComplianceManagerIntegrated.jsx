import React, { useState, useEffect } from 'react';
import { personalInfoAPI, documentAPI, complianceAPI } from '../lib/api';

export default function ComplianceManager() {
  const [activeTab, setActiveTab] = useState('personal');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  
  const [personalInfo, setPersonalInfo] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    nationalInsurance: '',
    profession: '',
    regulatoryBody: '',
    registrationNumber: '',
    everSuspended: null,
    suspensionDetails: '',
    underInvestigation: null,
    investigationDetails: '',
    // Referees
    referee1Name: '',
    referee1Position: '',
    referee1Organization: '',
    referee1Email: '',
    referee1Phone: '',
    referee2Name: '',
    referee2Position: '',
    referee2Organization: '',
    referee2Email: '',
    referee2Phone: ''
  });

  const [documents, setDocuments] = useState({
    // Standard Dataset & ID Check (1-11)
    passport: { file: null, status: 'Not Uploaded', expiryDate: null },
    driverLicense: { file: null, status: 'Not Uploaded', expiryDate: null },
    cv: { file: null, status: 'Not Uploaded', expiryDate: null },
    workPermit: { file: null, status: 'Not Uploaded', expiryDate: null },
    enhancedDBS: { file: null, status: 'Not Uploaded', expiryDate: null },
    insurance: { file: null, status: 'Not Uploaded', expiryDate: null },
    icoRegistration: { file: null, status: 'Not Uploaded', expiryDate: null },
    qualifications: { file: null, status: 'Not Uploaded', expiryDate: null },
    hepatitisB: { file: null, status: 'Not Uploaded', expiryDate: null },
    gmcRegistration: { file: null, status: 'Not Uploaded', expiryDate: null },
    nhsAppraisal: { file: null, status: 'Not Uploaded', expiryDate: null },
    // Additional Requirements (12-15)
    applicationForm: { file: null, status: 'Not Uploaded', expiryDate: null },
    signedPolicy: { file: null, status: 'Not Uploaded', expiryDate: null },
    criminalDeclaration: { file: null, status: 'Not Uploaded', expiryDate: null },
    consultantAgreement: { file: null, status: 'Not Uploaded', expiryDate: null }
  });

  const [complianceStatus, setComplianceStatus] = useState({
    overview: {
      totalDocuments: 15,
      uploadedDocuments: 0,
      validDocuments: 0,
      expiringDocuments: 0,
      expiredDocuments: 0,
      overallStatus: 'Incomplete'
    },
    documents: []
  });

  const professions = [
    'Optometrist',
    'Optometrist IP',
    'Optometrist IP + Glaucoma (Cert /H Cert / Dip)',
    'Ophthalmic Technician',
    'Dispensing Optician',
    'Ophthalmologist',
    'Ophthalmologist SR (Consultant)',
    'Audiologist',
    'ODP',
    'RN - Scrub Ophthalmology',
    'RN Scrub (other)',
    'HCA in Ophthalmology',
    'HCA - Other',
    'ENT Consultant',
    'Orthoptist',
    'GPwER - Minor Ops',
    'GPwER - Ophthalmology',
    'GPwER - Dermatology',
    'General Surgeon',
    'Endoscopy Consultant',
    'General Practitioner',
    'Nurse',
    'Dentist',
    'Pharmacist',
    'Physiotherapist',
    'Occupational Therapist',
    'Speech Therapist',
    'Radiographer',
    'Other'
  ];

  const regulatoryBodies = [
    'GMC (General Medical Council)',
    'GOC (General Optical Council)',
    'HCPC (Health and Care Professions Council)',
    'NMC (Nursing and Midwifery Council)',
    'GDC (General Dental Council)',
    'GPhC (General Pharmaceutical Council)'
  ];

  const documentCategories = {
    'Standard Dataset & ID Check': {
      passport: {
        title: 'Passport Copy',
        description: 'Copy of your current passport',
        required: true,
        renewalPeriod: 'As per passport validity'
      },
      driverLicense: {
        title: 'Driver\'s License Copy',
        description: 'Copy of your current driver\'s license',
        required: true,
        renewalPeriod: 'As per license validity'
      },
      cv: {
        title: 'Full CV',
        description: 'Complete curriculum vitae',
        required: true,
        renewalPeriod: 'Update as needed'
      },
      workPermit: {
        title: 'Work Permit',
        description: 'Work permit (if necessary)',
        required: false,
        renewalPeriod: 'As per permit validity'
      },
      enhancedDBS: {
        title: 'Enhanced DBS Certificate',
        description: 'Enhanced Disclosure and Barring Service certification for child and adult workforces',
        required: true,
        renewalPeriod: 'Every 3 years'
      },
      insurance: {
        title: 'Insurance Certificate',
        description: 'Valid certificate of adequate insurance cover or medical indemnity cover',
        required: true,
        renewalPeriod: 'Annual renewal'
      },
      icoRegistration: {
        title: 'ICO Registration',
        description: 'ICO registration or exemption certificate',
        required: true,
        renewalPeriod: 'Annual renewal'
      },
      qualifications: {
        title: 'Qualifications & Training',
        description: 'Evidence of qualifications, accreditations and training records',
        required: true,
        renewalPeriod: 'Ongoing updates'
      },
      hepatitisB: {
        title: 'Hepatitis B Status',
        description: 'Hepatitis B antibody and antigen status result',
        required: true,
        renewalPeriod: 'Every 5 years'
      },
      gmcRegistration: {
        title: 'Professional Registration',
        description: 'Current registration with GMC/GOC and specialist register',
        required: true,
        renewalPeriod: 'Annual renewal'
      },
      nhsAppraisal: {
        title: 'NHS Appraisal',
        description: 'Form of last NHS Appraisal or career development evidence',
        required: false,
        renewalPeriod: 'Annual'
      }
    },
    'Additional Requirements': {
      applicationForm: {
        title: 'Application Form',
        description: 'Completed application form',
        required: true,
        renewalPeriod: 'One-time'
      },
      signedPolicy: {
        title: 'Signed Policy',
        description: 'Signed policy documents',
        required: true,
        renewalPeriod: 'As updated'
      },
      criminalDeclaration: {
        title: 'Criminal Self Declaration',
        description: 'Criminal self declaration form',
        required: true,
        renewalPeriod: 'Annual'
      },
      consultantAgreement: {
        title: 'Consultant Agreement',
        description: 'Associated Consultant Agreement',
        required: true,
        renewalPeriod: 'As per agreement'
      }
    }
  };

  // Load data on component mount
  useEffect(() => {
    loadPersonalInformation();
    loadDocuments();
    loadComplianceStatus();
  }, []);

  const loadPersonalInformation = async () => {
    try {
      const data = await personalInfoAPI.get();
      setPersonalInfo(prev => ({ ...prev, ...data }));
    } catch (error) {
      console.error('Error loading personal information:', error);
    }
  };

  const loadDocuments = async () => {
    try {
      const data = await documentAPI.getAll();
      setDocuments(prev => ({ ...prev, ...data }));
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };

  const loadComplianceStatus = async () => {
    try {
      const data = await complianceAPI.getStatus();
      setComplianceStatus(data);
    } catch (error) {
      console.error('Error loading compliance status:', error);
    }
  };

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 5000);
  };

  const handlePersonalInfoChange = (field, value) => {
    setPersonalInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSavePersonalInfo = async () => {
    setSaving(true);
    try {
      await personalInfoAPI.save(personalInfo);
      showMessage('success', 'Personal information saved successfully!');
    } catch (error) {
      showMessage('error', 'Failed to save personal information. Please try again.');
      console.error('Error saving personal information:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (documentType, file) => {
    setUploading(true);
    try {
      const result = await documentAPI.upload(documentType, file);
      
      // Update documents state
      setDocuments(prev => ({
        ...prev,
        [documentType]: {
          file: file.name,
          status: result.document.status,
          expiryDate: result.document.expiryDate,
          aiConfidence: result.document.aiConfidence
        }
      }));
      
      // Reload compliance status
      await loadComplianceStatus();
      
      showMessage('success', `${file.name} uploaded successfully! AI detected expiry date with ${result.document.aiConfidence}% confidence.`);
    } catch (error) {
      showMessage('error', 'Failed to upload document. Please try again.');
      console.error('Error uploading document:', error);
    } finally {
      setUploading(false);
    }
  };

  const getStatusColor = (status, expiryDate) => {
    if (status === 'Not Uploaded') return 'gray';
    if (!expiryDate) return 'blue';
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) return 'red'; // Expired
    if (daysUntilExpiry <= 30) return 'orange'; // Expiring soon (1-30 days)
    if (daysUntilExpiry <= 90) return 'yellow'; // Warning (30-90 days)
    return 'green'; // Valid (90+ days)
  };

  const getStatusText = (status, expiryDate) => {
    if (status === 'Not Uploaded') return 'Not Uploaded';
    if (!expiryDate) return 'Uploaded';
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry < 0) return 'Expired';
    if (daysUntilExpiry <= 30) return `Expires in ${daysUntilExpiry} days`;
    if (daysUntilExpiry <= 90) return `Expires in ${daysUntilExpiry} days`;
    return `Valid until ${expiry.toLocaleDateString()}`;
  };

  const renderPersonalInformation = () => (
    <div className="space-y-8">
      {message.text && (
        <div className={`p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-50 text-green-800 border border-green-200' :
          'bg-red-50 text-red-800 border border-red-200'
        }`}>
          {message.text}
        </div>
      )}
      
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-6">Personal Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              First Name *
            </label>
            <input
              type="text"
              value={personalInfo.firstName}
              onChange={(e) => handlePersonalInfoChange('firstName', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Last Name *
            </label>
            <input
              type="text"
              value={personalInfo.lastName}
              onChange={(e) => handlePersonalInfoChange('lastName', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date of Birth *
            </label>
            <input
              type="date"
              value={personalInfo.dateOfBirth}
              onChange={(e) => handlePersonalInfoChange('dateOfBirth', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              National Insurance Number *
            </label>
            <input
              type="text"
              placeholder="AB123456C"
              value={personalInfo.nationalInsurance}
              onChange={(e) => handlePersonalInfoChange('nationalInsurance', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Profession *
            </label>
            <select
              value={personalInfo.profession}
              onChange={(e) => handlePersonalInfoChange('profession', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Profession</option>
              {professions.map(prof => (
                <option key={prof} value={prof}>{prof}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Regulatory Body *
            </label>
            <select
              value={personalInfo.regulatoryBody}
              onChange={(e) => handlePersonalInfoChange('regulatoryBody', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Regulatory Body</option>
              {regulatoryBodies.map(body => (
                <option key={body} value={body}>{body}</option>
              ))}
            </select>
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Registration/License Number *
            </label>
            <input
              type="text"
              value={personalInfo.registrationNumber}
              onChange={(e) => handlePersonalInfoChange('registrationNumber', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Referees Section */}
      <div className="border-t pt-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Professional Referees</h3>
        <p className="text-sm text-gray-600 mb-6">Please provide details for 2 professional referees</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Referee 1 */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-800">Referee 1 *</h4>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Full Name"
                value={personalInfo.referee1Name}
                onChange={(e) => handlePersonalInfoChange('referee1Name', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Position/Title"
                value={personalInfo.referee1Position}
                onChange={(e) => handlePersonalInfoChange('referee1Position', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Organization"
                value={personalInfo.referee1Organization}
                onChange={(e) => handlePersonalInfoChange('referee1Organization', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="email"
                placeholder="Email Address"
                value={personalInfo.referee1Email}
                onChange={(e) => handlePersonalInfoChange('referee1Email', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                value={personalInfo.referee1Phone}
                onChange={(e) => handlePersonalInfoChange('referee1Phone', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          
          {/* Referee 2 */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-800">Referee 2 *</h4>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Full Name"
                value={personalInfo.referee2Name}
                onChange={(e) => handlePersonalInfoChange('referee2Name', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Position/Title"
                value={personalInfo.referee2Position}
                onChange={(e) => handlePersonalInfoChange('referee2Position', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Organization"
                value={personalInfo.referee2Organization}
                onChange={(e) => handlePersonalInfoChange('referee2Organization', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="email"
                placeholder="Email Address"
                value={personalInfo.referee2Email}
                onChange={(e) => handlePersonalInfoChange('referee2Email', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                value={personalInfo.referee2Phone}
                onChange={(e) => handlePersonalInfoChange('referee2Phone', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Regulatory Compliance */}
      <div className="border-t pt-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Regulatory Compliance</h3>
        
        <div className="space-y-6">
          <div>
            <p className="text-sm font-medium text-gray-700 mb-3">
              Have you ever been suspended or struck off the register by your regulatory body?
            </p>
            <div className="flex space-x-6 mb-3">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="everSuspended"
                  value="no"
                  checked={personalInfo.everSuspended === false}
                  onChange={() => handlePersonalInfoChange('everSuspended', false)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">NO</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="everSuspended"
                  value="yes"
                  checked={personalInfo.everSuspended === true}
                  onChange={() => handlePersonalInfoChange('everSuspended', true)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">YES</span>
              </label>
            </div>
            {personalInfo.everSuspended === true && (
              <textarea
                value={personalInfo.suspensionDetails}
                onChange={(e) => handlePersonalInfoChange('suspensionDetails', e.target.value)}
                placeholder="Please give details"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="3"
              />
            )}
          </div>
          
          <div>
            <p className="text-sm font-medium text-gray-700 mb-3">
              Are you currently under investigation by, or have you ever been investigated by, a regulatory body?
            </p>
            <div className="flex space-x-6 mb-3">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="underInvestigation"
                  value="no"
                  checked={personalInfo.underInvestigation === false}
                  onChange={() => handlePersonalInfoChange('underInvestigation', false)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">NO</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="underInvestigation"
                  value="yes"
                  checked={personalInfo.underInvestigation === true}
                  onChange={() => handlePersonalInfoChange('underInvestigation', true)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">YES</span>
              </label>
            </div>
            {personalInfo.underInvestigation === true && (
              <textarea
                value={personalInfo.investigationDetails}
                onChange={(e) => handlePersonalInfoChange('investigationDetails', e.target.value)}
                placeholder="Please give details"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="3"
              />
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleSavePersonalInfo}
          disabled={saving}
          className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
        >
          {saving ? 'Saving...' : 'Save Personal Information'}
        </button>
      </div>
    </div>
  );

  const renderDocumentManagement = () => (
    <div className="space-y-8">
      {message.text && (
        <div className={`p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-50 text-green-800 border border-green-200' :
          'bg-red-50 text-red-800 border border-red-200'
        }`}>
          {message.text}
        </div>
      )}
      
      {Object.entries(documentCategories).map(([categoryName, categoryDocs]) => (
        <div key={categoryName} className="border rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">{categoryName}</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(categoryDocs).map(([docKey, docInfo]) => {
              const doc = documents[docKey];
              const statusColor = getStatusColor(doc.status, doc.expiryDate);
              const statusText = getStatusText(doc.status, doc.expiryDate);
              
              return (
                <div key={docKey} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-gray-900">
                        {docInfo.title}
                        {docInfo.required && <span className="text-red-500 ml-1">*</span>}
                      </h4>
                      <p className="text-sm text-gray-600 mt-1">{docInfo.description}</p>
                      <p className="text-xs text-gray-500 mt-1">Renewal: {docInfo.renewalPeriod}</p>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${
                      statusColor === 'gray' ? 'bg-gray-400' :
                      statusColor === 'green' ? 'bg-green-500' :
                      statusColor === 'yellow' ? 'bg-yellow-500' :
                      statusColor === 'orange' ? 'bg-orange-500' :
                      statusColor === 'red' ? 'bg-red-500' : 'bg-blue-500'
                    }`}></div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Status:</span>
                      <span className={`text-sm font-medium ${
                        statusColor === 'gray' ? 'text-gray-600' :
                        statusColor === 'green' ? 'text-green-600' :
                        statusColor === 'yellow' ? 'text-yellow-600' :
                        statusColor === 'orange' ? 'text-orange-600' :
                        statusColor === 'red' ? 'text-red-600' : 'text-blue-600'
                      }`}>
                        {statusText}
                      </span>
                    </div>
                    
                    {doc.aiConfidence && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">AI Confidence:</span>
                        <span className="text-sm text-blue-600">{doc.aiConfidence}%</span>
                      </div>
                    )}
                    
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                      onChange={(e) => {
                        if (e.target.files[0]) {
                          handleFileUpload(docKey, e.target.files[0]);
                        }
                      }}
                      disabled={uploading}
                      className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 disabled:opacity-50"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );

  const renderComplianceOverview = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Compliance Status Overview</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {complianceStatus.overview.uploadedDocuments}/{complianceStatus.overview.totalDocuments}
            </div>
            <div className="text-sm text-blue-800">Documents Uploaded</div>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {complianceStatus.overview.validDocuments}
            </div>
            <div className="text-sm text-green-800">Valid Documents</div>
          </div>
          <div className="bg-orange-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">
              {complianceStatus.overview.expiringDocuments}
            </div>
            <div className="text-sm text-orange-800">Expiring Soon</div>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-red-600">
              {complianceStatus.overview.expiredDocuments}
            </div>
            <div className="text-sm text-red-800">Expired</div>
          </div>
        </div>
      </div>

      <div>
        <h4 className="font-medium text-gray-900 mb-4">Document Status Details</h4>
        <div className="space-y-3">
          {complianceStatus.documents.map((doc) => (
            <div key={doc.type} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${
                  doc.color === 'gray' ? 'bg-gray-400' :
                  doc.color === 'green' ? 'bg-green-500' :
                  doc.color === 'yellow' ? 'bg-yellow-500' :
                  doc.color === 'orange' ? 'bg-orange-500' :
                  doc.color === 'red' ? 'bg-red-500' : 'bg-blue-500'
                }`}></div>
                <span className="font-medium text-gray-900">
                  {doc.title}
                  {doc.required && <span className="text-red-500 ml-1">*</span>}
                </span>
              </div>
              <span className={`text-sm font-medium ${
                doc.color === 'gray' ? 'text-gray-600' :
                doc.color === 'green' ? 'text-green-600' :
                doc.color === 'yellow' ? 'text-yellow-600' :
                doc.color === 'orange' ? 'text-orange-600' :
                doc.color === 'red' ? 'text-red-600' : 'text-blue-600'
              }`}>
                {doc.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {(complianceStatus.overview.expiredDocuments > 0 || complianceStatus.overview.expiringDocuments > 0) && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h4 className="font-medium text-yellow-800 mb-2">⚠️ Alerts & Warnings</h4>
          <ul className="text-sm text-yellow-700 space-y-1">
            {complianceStatus.overview.expiredDocuments > 0 && (
              <li>• {complianceStatus.overview.expiredDocuments} document(s) have expired and need immediate renewal</li>
            )}
            {complianceStatus.overview.expiringDocuments > 0 && (
              <li>• {complianceStatus.overview.expiringDocuments} document(s) are expiring within 30 days</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );

  return (
    <div className="bg-white rounded-lg shadow-sm border">
      <div className="border-b border-gray-200">
        <div className="px-6 py-4">
          <h2 className="text-xl font-semibold text-gray-900">Information Control Center</h2>
          <p className="text-sm text-gray-600 mt-1">Manage your professional information and compliance documents</p>
        </div>
        
        <div className="flex space-x-8 px-6">
          <button
            onClick={() => setActiveTab('personal')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'personal'
                ? 'border-purple-500 text-purple-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Personal Information
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'documents'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Document Management
          </button>
          <button
            onClick={() => setActiveTab('compliance')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'compliance'
                ? 'border-pink-500 text-pink-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Compliance Overview
          </button>
        </div>
      </div>
      
      <div className="p-6">
        {activeTab === 'personal' && renderPersonalInformation()}
        {activeTab === 'documents' && renderDocumentManagement()}
        {activeTab === 'compliance' && renderComplianceOverview()}
      </div>
      
      {uploading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span>Processing document with AI...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

