import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';

export default function ProviderRegistration() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    legal_name: '',
    trading_name: '',
    cqc_number: '',
    ods_code: '',
    primary_contact_name: '',
    primary_contact_email: '',
    primary_contact_phone: '',
    billing_contact_name: '',
    billing_contact_email: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    if (!formData.cqc_number && !formData.ods_code) {
      setError('Either CQC Registration Number or ODS Code is required');
      setLoading(false);
      return;
    }

    try {
      const registrationData = {
        ...formData,
        role: 'provider'
      };
      delete registrationData.confirmPassword;

      const result = await register(registrationData);
      
      if (result.success) {
        navigate('/dashboard');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Register as Provider/Clinic</h2>
            <p className="mt-2 text-gray-600">Join our network of trusted healthcare providers</p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Organization Information */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Organization Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="legal_name" className="block text-sm font-medium text-gray-700 mb-1">
                    Legal Name *
                  </label>
                  <input
                    id="legal_name"
                    name="legal_name"
                    type="text"
                    required
                    value={formData.legal_name}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label htmlFor="trading_name" className="block text-sm font-medium text-gray-700 mb-1">
                    Trading Name
                  </label>
                  <input
                    id="trading_name"
                    name="trading_name"
                    type="text"
                    value={formData.trading_name}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                  <label htmlFor="cqc_number" className="block text-sm font-medium text-gray-700 mb-1">
                    CQC Registration Number
                  </label>
                  <input
                    id="cqc_number"
                    name="cqc_number"
                    type="text"
                    value={formData.cqc_number}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label htmlFor="ods_code" className="block text-sm font-medium text-gray-700 mb-1">
                    ODS Code
                  </label>
                  <input
                    id="ods_code"
                    name="ods_code"
                    type="text"
                    value={formData.ods_code}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>
              
              <p className="text-sm text-gray-500 mt-2">
                * At least one of CQC Registration Number or ODS Code is required
              </p>
            </div>

            {/* Account Information */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Information</h3>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    Password *
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm Password *
                  </label>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    required
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="primary_contact_name" className="block text-sm font-medium text-gray-700 mb-1">
                    Primary Contact Name
                  </label>
                  <input
                    id="primary_contact_name"
                    name="primary_contact_name"
                    type="text"
                    value={formData.primary_contact_name}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label htmlFor="primary_contact_email" className="block text-sm font-medium text-gray-700 mb-1">
                    Primary Contact Email
                  </label>
                  <input
                    id="primary_contact_email"
                    name="primary_contact_email"
                    type="email"
                    value={formData.primary_contact_email}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                  <label htmlFor="primary_contact_phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Primary Contact Phone
                  </label>
                  <input
                    id="primary_contact_phone"
                    name="primary_contact_phone"
                    type="tel"
                    value={formData.primary_contact_phone}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label htmlFor="billing_contact_name" className="block text-sm font-medium text-gray-700 mb-1">
                    Billing Contact Name
                  </label>
                  <input
                    id="billing_contact_name"
                    name="billing_contact_name"
                    type="text"
                    value={formData.billing_contact_name}
                    onChange={handleChange}
                    className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>

              <div className="mt-6">
                <label htmlFor="billing_contact_email" className="block text-sm font-medium text-gray-700 mb-1">
                  Billing Contact Email
                </label>
                <input
                  id="billing_contact_email"
                  name="billing_contact_email"
                  type="email"
                  value={formData.billing_contact_email}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-6">
              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white py-3 rounded-xl font-semibold"
              >
                {loading ? 'Creating Account...' : 'Create Provider Account'}
              </Button>
            </div>

            {/* Sign In Link */}
            <div className="text-center pt-4">
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/')}
                  className="font-semibold text-indigo-600 hover:text-indigo-700"
                >
                  Sign In
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

