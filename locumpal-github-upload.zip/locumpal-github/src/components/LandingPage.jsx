import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import locumpalLogo from "../assets/locumpal-logo.png";

export default function LandingPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSignIn = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    const data = new FormData(e.currentTarget);
    const email = data.get("email");
    const password = data.get("password");
    
    try {
      const result = await login(email, password);
      if (result.success) {
        navigate('/dashboard');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Sign in failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gray-50 text-gray-900">
      <div className="grid min-h-screen grid-cols-1 lg:grid-cols-2">
        {/* Left / Marketing Panel */}
        <div className="relative flex items-center justify-center p-8 lg:p-12 overflow-hidden bg-gradient-to-br from-indigo-100 via-purple-100 to-transparent">
          {/* soft shapes */}
          <div className="pointer-events-none absolute -left-24 -top-24 h-80 w-80 rounded-full bg-indigo-300/30 blur-3xl" />
          <div className="pointer-events-none absolute -right-24 -bottom-24 h-96 w-96 rounded-full bg-purple-300/30 blur-3xl" />

          <div className="relative z-10 w-full max-w-md">
            <div className="mx-auto rounded-2xl bg-white/80 p-8 shadow-xl ring-1 ring-black/5 backdrop-blur">
              {/* Logo block */}
              <div className="mb-6 flex items-center justify-center">
                <img 
                  src={locumpalLogo} 
                  alt="LocumPal Logo" 
                  className="h-20 w-auto"
                />
              </div>
              
              <div className="text-center mb-6">
                <p className="text-lg text-gray-700 mb-4">
                  A trustworthy marketplace where UK clinics can open sessions and instantly alert vetted clinicians to cover them.
                </p>
                <p className="text-sm text-gray-600 italic">
                  Emphasis on compliance, governance, and efficiency.
                </p>
              </div>

              {/* CTA buttons */}
              <div className="space-y-3">
                <button
                  className="inline-flex w-full items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                  onClick={() => navigate('/register/locum')}
                >
                  Register as Locum
                </button>
                
                <button
                  className="inline-flex w-full items-center justify-center rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 px-5 py-3 text-sm font-semibold text-white shadow hover:from-cyan-600 hover:to-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500"
                  onClick={() => navigate('/register/provider')}
                >
                  Register as Provider/Clinic
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right / Sign In Panel */}
        <div className="flex items-center justify-center p-8 lg:p-12">
          <div className="w-full max-w-md">
            <div className="rounded-2xl bg-white p-8 shadow-xl ring-1 ring-gray-200">
              <h2 className="mb-6 text-center text-2xl font-semibold">Sign In</h2>
              
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}
              
              <form className="space-y-5" onSubmit={handleSignIn}>
                <div>
                  <label htmlFor="email" className="mb-1 block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    disabled={loading}
                    className="block w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50"
                    placeholder="you@example.com"
                  />
                </div>
                <div>
                  <label htmlFor="password" className="mb-1 block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    disabled={loading}
                    className="block w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50"
                    placeholder="••••••••"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="mt-2 inline-flex w-full items-center justify-center rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-blue-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Signing In...' : 'Sign In'}
                </button>
              </form>
              <p className="mt-5 text-center text-sm text-gray-600">
                Don&apos;t have an account?{' '}
                <button 
                  className="font-semibold text-indigo-600 hover:text-indigo-700" 
                  onClick={() => navigate('/register')}
                  disabled={loading}
                >
                  Register
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

