# LocumPal Healthcare Compliance Platform

A comprehensive healthcare compliance management system for UK clinics and locums.

## Features

- ✅ Complete credentialing system (15 document types)
- ✅ AI-powered expiry detection
- ✅ Real-time compliance monitoring
- ✅ Professional referees management
- ✅ 29 medical specialties support
- ✅ Full authentication system
- ✅ Optimized for 10,000+ users

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + ShadCN UI
- **Backend**: Flask API (deployed separately)
- **Authentication**: JWT tokens
- **Deployment**: Vercel

## Environment Variables

```
VITE_API_BASE_URL=https://mzhyi8c1zo9v.manus.space
```

## Deployment

This project is configured for automatic deployment on Vercel.

## Backend

The backend API is deployed at: https://mzhyi8c1zo9v.manus.space

## License

Private - Healthcare Compliance System

